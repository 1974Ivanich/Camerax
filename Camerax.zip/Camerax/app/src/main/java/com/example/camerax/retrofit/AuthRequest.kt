package com.example.camerax.retrofit

data class AuthRequest(
    val filename: String,
    val image: String
)
